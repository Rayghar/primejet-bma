// src/api/glService.js
import apiClient from "./apiClient";

/**
 * GL Service (v2)
 * - Calls GL orchestrator endpoints (GL-first flow)
 * - These endpoints must exist in backend gl.routes.js + gl.controller.js
 *
 * Endpoints:
 * - POST /api/v2/gl/bootstrap
 * - POST /api/v2/gl/rebuild
 * - GET  /api/v2/gl/trial-balance
 * - POST /api/v2/gl/post-approved
 * - POST /api/v2/gl/retry-failed
 * - GET  /api/v2/gl/posting-exceptions
 * - GET  /api/v2/gl/health
 * - GET  /api/v2/gl/journals          (optional drill-down)
 * - POST /api/v2/gl/reverse           (optional)
 */

const hasVal = (v) => v !== undefined && v !== null && String(v).trim() !== "";

// backend treats branchId == serviceZoneId (we send both for safety)
const withBranchParams = (branchIdOrZoneId) => {
  if (!hasVal(branchIdOrZoneId)) return {};
  return { branchId: branchIdOrZoneId, serviceZoneId: branchIdOrZoneId };
};

const normalizeApiError = (err, fallback = "Request failed") => {
  const status = err?.response?.status;
  const serverMsg = err?.response?.data?.message || err?.response?.data?.error || err?.response?.data?.msg;
  const msg = serverMsg || err?.message || fallback;

  const e = new Error(msg);
  e.status = status;
  e.raw = err;
  throw e;
};

const requireRange = (startDate, endDate, label = "startDate and endDate are required") => {
  if (!hasVal(startDate) || !hasVal(endDate)) {
    const e = new Error(label);
    e.code = "MISSING_RANGE";
    throw e;
  }
};

// -------------------------
// COA / bootstrap
// -------------------------
export const glBootstrap = async () => {
  try {
    const res = await apiClient.post("/api/v2/gl/bootstrap");
    return res.data;
  } catch (err) {
    normalizeApiError(err, "Failed to bootstrap GL");
  }
};

// -------------------------
// Rebuild / trial balance
// -------------------------
export const glRebuild = async ({ startDate, endDate, branchIdOrZoneId } = {}) => {
  try {
    requireRange(startDate, endDate);

    const params = {
      startDate,
      endDate,
      ...withBranchParams(branchIdOrZoneId),
    };

    const res = await apiClient.post("/api/v2/gl/rebuild", null, { params });
    return res.data;
  } catch (err) {
    normalizeApiError(err, "Failed to rebuild GL");
  }
};

export const glTrialBalance = async ({ startDate, endDate, branchIdOrZoneId } = {}) => {
  try {
    requireRange(startDate, endDate);

    const params = {
      startDate,
      endDate,
      ...withBranchParams(branchIdOrZoneId),
    };

    const res = await apiClient.get("/api/v2/gl/trial-balance", { params });
    return res.data;
  } catch (err) {
    normalizeApiError(err, "Failed to load trial balance");
  }
};

// -------------------------
// Posting orchestration
// -------------------------
export const glPostApproved = async ({ businessDate, branchIdOrZoneId } = {}) => {
  try {
    if (!hasVal(businessDate)) throw new Error("businessDate is required");

    // backend expects businessDate; include legacy date as fallback
    const params = {
      businessDate,
      date: businessDate,
      ...withBranchParams(branchIdOrZoneId),
    };

    const res = await apiClient.post("/api/v2/gl/post-approved", null, { params });
    return res.data;
  } catch (err) {
    normalizeApiError(err, "Failed to post approved documents to GL");
  }
};

export const glRetryFailed = async ({ startDate, endDate, branchIdOrZoneId } = {}) => {
  try {
    requireRange(startDate, endDate);

    const params = {
      startDate,
      endDate,
      ...withBranchParams(branchIdOrZoneId),
    };

    const res = await apiClient.post("/api/v2/gl/retry-failed", null, { params });
    return res.data;
  } catch (err) {
    normalizeApiError(err, "Failed to retry failed postings");
  }
};

export const glPostingExceptions = async ({ startDate, endDate, branchIdOrZoneId } = {}) => {
  try {
    requireRange(startDate, endDate);

    const params = {
      startDate,
      endDate,
      ...withBranchParams(branchIdOrZoneId),
    };

    const res = await apiClient.get("/api/v2/gl/posting-exceptions", { params });
    return res.data;
  } catch (err) {
    normalizeApiError(err, "Failed to load posting exceptions");
  }
};

// -------------------------
// Health
// -------------------------
export const glHealth = async ({ startDate, endDate, branchIdOrZoneId } = {}) => {
  try {
    const params = {
      ...(hasVal(startDate) ? { startDate } : {}),
      ...(hasVal(endDate) ? { endDate } : {}),
      ...withBranchParams(branchIdOrZoneId),
    };

    const res = await apiClient.get("/api/v2/gl/health", { params });
    return res.data;
  } catch (err) {
    normalizeApiError(err, "Failed to load GL health");
  }
};

// -------------------------
// Optional: drill-down journals (for modals / preview panels)
// -------------------------
export const glListJournals = async ({ startDate, endDate, branchIdOrZoneId, sourceType, sourceId } = {}) => {
  try {
    const params = {
      ...(hasVal(startDate) ? { startDate } : {}),
      ...(hasVal(endDate) ? { endDate } : {}),
      ...withBranchParams(branchIdOrZoneId),
      ...(hasVal(sourceType) ? { sourceType } : {}),
      ...(hasVal(sourceId) ? { sourceId } : {}),
    };

    const res = await apiClient.get("/api/v2/gl/journals", { params });
    return res.data;
  } catch (err) {
    normalizeApiError(err, "Failed to load journals");
  }
};

// -------------------------
// Optional: reversal
// -------------------------
export const glReverse = async ({ glEntryId, reversalDate, narration, postingVersion } = {}) => {
  try {
    if (!hasVal(glEntryId)) throw new Error("glEntryId is required");

    const payload = {
      glEntryId,
      ...(hasVal(reversalDate) ? { reversalDate } : {}),
      ...(hasVal(narration) ? { narration } : {}),
      ...(postingVersion !== undefined && postingVersion !== null ? { postingVersion } : {}),
    };

    const res = await apiClient.post("/api/v2/gl/reverse", payload);
    return res.data;
  } catch (err) {
    normalizeApiError(err, "Failed to reverse journal");
  }
};