// src/api/dataEntryService.js
import httpClient from "./httpClient";
import { glPostApproved, glRetryFailed, glPostingExceptions } from "./glService";

/**
 * Data Entry Service (GL-aligned)
 *
 * IMPORTANT:
 * - httpClient baseURL ALREADY includes:  <API_URL>/api/v2
 * - Therefore: DO NOT prefix "/api/v2" in the paths below,
 *   or you will get: /api/v2/api/v2/... (404)
 *
 * Goals:
 * - Keep existing /data-entry routes intact (legacy-compatible)
 * - Add Daily Summary helpers required by DailyLog + CloseWorkspace
 * - Add GL-first helpers used by Close Workspace UI (delegates posting to GL service)
 *
 * Backend alias routes expected (full paths shown for clarity):
 *   POST   /api/v2/data-entry/daily-summary/get-or-create
 *   GET    /api/v2/data-entry/daily-summary/entries?summaryId=...
 *   PATCH  /api/v2/data-entry/daily-summary/:summaryId/meters
 *   POST   /api/v2/data-entry/daily-summary/:summaryId/sales
 *   POST   /api/v2/data-entry/daily-summary/:summaryId/expenses
 *   POST   /api/v2/data-entry/daily-summary/:summaryId/finalize
 *   GET    /api/v2/data-entry/transactions/history
 *
 * In this client file (because baseURL already includes /api/v2),
 * we call them as:
 *   /data-entry/...
 */

const hasVal = (v) => v !== undefined && v !== null && String(v).trim() !== "";

const normalizeBranchParams = (branchIdOrZoneId) => {
  if (!hasVal(branchIdOrZoneId)) return {};
  // backend treats branchId and serviceZoneId interchangeably
  return { branchId: branchIdOrZoneId, serviceZoneId: branchIdOrZoneId };
};

// -------------------- existing API wrappers --------------------

export const getDataEntries = async (filters = {}, options = {}) => {
  const { data } = await httpClient.get("/data-entry", { params: filters, ...options });
  return data;
};

export const createDataEntry = async (payload, options = {}) => {
  const { data } = await httpClient.post("/data-entry", payload, options);
  return data;
};

export const updateDataEntry = async (id, payload, options = {}) => {
  const { data } = await httpClient.patch(`/data-entry/${id}`, payload, options);
  return data;
};

export const submitDataEntry = async (id, options = {}) => {
  const { data } = await httpClient.post(`/data-entry/${id}/submit`, null, options);
  return data;
};

export const approveDataEntry = async (id, options = {}) => {
  const { data } = await httpClient.post(`/data-entry/${id}/approve`, null, options);
  return data;
};

export const rejectDataEntry = async (id, payload, options = {}) => {
  const { data } = await httpClient.post(`/data-entry/${id}/reject`, payload, options);
  return data;
};

// -------------------- GL-first helpers --------------------

/**
 * Post all approved operational docs for a business date + branch.
 * Used by Close Workspace "Post Approved".
 */
export const postApprovedToGLForDay = async ({ businessDate, branchIdOrZoneId } = {}) => {
  if (!hasVal(businessDate)) {
    throw new Error("postApprovedToGLForDay: businessDate is required (YYYY-MM-DD)");
  }
  return glPostApproved({ businessDate, branchIdOrZoneId });
};

/**
 * Retry failed postings in a date range.
 */
export const retryFailedPostings = async ({ startDate, endDate, branchIdOrZoneId } = {}) => {
  if (!hasVal(startDate) || !hasVal(endDate)) {
    throw new Error("retryFailedPostings: startDate and endDate are required (YYYY-MM-DD)");
  }
  return glRetryFailed({ startDate, endDate, branchIdOrZoneId });
};

/**
 * Fetch posting exceptions grouped by reason.
 */
export const getPostingExceptions = async ({ startDate, endDate, branchIdOrZoneId } = {}) => {
  if (!hasVal(startDate) || !hasVal(endDate)) {
    throw new Error("getPostingExceptions: startDate and endDate are required (YYYY-MM-DD)");
  }
  return glPostingExceptions({ startDate, endDate, branchIdOrZoneId });
};

// -------------------- Daily Summary helpers (required by DailyLog + CloseWorkspace) --------------------

/**
 * Create or fetch the Daily Summary for a branch + date.
 * Payload expected by backend: { branchId, date, cashierName, pricePerKg }
 */
export const createOrGetDailySummary = async (payload, options = {}) => {
  const { data } = await httpClient.post("/data-entry/daily-summary/get-or-create", payload, options);
  return data;
};

/**
 * Fetch entries and summary rollups.
 * Uses alias endpoint: /daily-summary/entries?summaryId=...
 */
export const getDailyEntries = async ({ summaryId, ...params } = {}, options = {}) => {
  if (!hasVal(summaryId)) {
    throw new Error("getDailyEntries: summaryId is required");
  }

  const { data } = await httpClient.get("/data-entry/daily-summary/entries", {
    params: { summaryId, ...params },
    ...options,
  });
  return data;
};

/**
 * Update opening/closing meters.
 * PATCH /daily-summary/:summaryId/meters
 */
export const updateSummaryMeters = async ({ summaryId, ...payload } = {}, options = {}) => {
  if (!hasVal(summaryId)) {
    throw new Error("updateSummaryMeters: summaryId is required");
  }

  const { data } = await httpClient.patch(`/data-entry/daily-summary/${summaryId}/meters`, payload, options);
  return data;
};

/**
 * Log a sale entry into the daily summary.
 * POST /daily-summary/:summaryId/sales
 */
export const logSale = async ({ summaryId, ...payload } = {}, options = {}) => {
  if (!hasVal(summaryId)) {
    throw new Error("logSale: summaryId is required");
  }

  const { data } = await httpClient.post(`/data-entry/daily-summary/${summaryId}/sales`, payload, options);
  return data;
};

/**
 * Log an expense entry into the daily summary.
 * POST /daily-summary/:summaryId/expenses
 */
export const logExpense = async ({ summaryId, ...payload } = {}, options = {}) => {
  if (!hasVal(summaryId)) {
    throw new Error("logExpense: summaryId is required");
  }

  const { data } = await httpClient.post(`/data-entry/daily-summary/${summaryId}/expenses`, payload, options);
  return data;
};

/**
 * Finalize/submit the summary (locks totals and moves status forward server-side).
 * POST /daily-summary/:summaryId/finalize
 */
export const finalizeDailySummary = async ({ summaryId, ...payload } = {}, options = {}) => {
  if (!hasVal(summaryId)) {
    throw new Error("finalizeDailySummary: summaryId is required");
  }

  const { data } = await httpClient.post(`/data-entry/daily-summary/${summaryId}/finalize`, payload, options);
  return data;
};

// -------------------- Approval Queue compatibility --------------------

/**
 * For ApprovalQueue UI.
 * Uses existing list endpoint with status filter.
 */
export const getPendingApprovals = async (filters = {}, options = {}) => {
  const params = {
    ...filters,
    status: filters.status || "pending_approval",
    ...normalizeBranchParams(filters.branchIdOrZoneId),
  };

  // Remove helper-only input to avoid confusing backend
  delete params.branchIdOrZoneId;

  const { data } = await httpClient.get("/data-entry", { params, ...options });
  return data;
};

export const approveSummary = async (id, options = {}) => approveDataEntry(id, options);

export const rejectSummary = async (id, payload, options = {}) => rejectDataEntry(id, payload, options);

// -------------------- Transaction history --------------------

export const getTransactionHistory = async (params = {}, options = {}) => {
  const merged = { ...params, ...normalizeBranchParams(params.branchIdOrZoneId) };
  delete merged.branchIdOrZoneId;

  const { data } = await httpClient.get("/data-entry/transactions/history", {
    params: merged,
    ...options,
  });
  return data;
};