export { default } from "./JournalViewerModal";
